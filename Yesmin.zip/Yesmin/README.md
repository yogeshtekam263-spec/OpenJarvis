# Yesmin - Jarvis style AI girlfriend assistant (Gemini brain)

## Termux mein build
pkg update && pkg install openjdk-17 gradle unzip wget
# Android SDK chahiye (cmdline-tools se): platforms;android-34, build-tools;34.0.0
export ANDROID_HOME=$HOME/android-sdk
cd Yesmin && gradle assembleDebug
APK: app/build/outputs/apk/debug/app-debug.apk
(aapt2 error aaye to gradle.properties mein aapt2FromMavenOverride line kholo)

## Sabse easy: GitHub Actions
Is folder ko GitHub repo mein push karo -> Actions tab -> "Build APK" -> artifact download -> install.

## Naya action jodna
1. Actions.kt ke `when` mein naya case likho.
2. Brain.kt ke RULES mein uska naam + params likho.
