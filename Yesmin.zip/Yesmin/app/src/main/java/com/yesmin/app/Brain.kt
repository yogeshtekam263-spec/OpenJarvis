package com.yesmin.app
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Brain {
    private val history = mutableListOf<Pair<String, String>>() // role, text
    private const val RULES = """
Tum hamesha SIRF valid JSON return karo: {"reply":"...","action":null} ya {"reply":"...","action":{"type":"...","params":{...}}}.
Allowed action types:
open_app{name}, youtube{query}, call{number}, sms{number,text}, whatsapp{number,text}, alarm{hour,minute}, timer{seconds},
maps{query}, flashlight{on:true/false}, settings{page: wifi|bluetooth|main}, tap_text{text}, tap{x,y}, swipe{direction: up|down|left|right},
scroll{direction: up|down}, type{text}, back, home, recents, read_screen, search_web{query}.
Agar action ki zaroorat nahi to action null rakho. Reply chhota aur bolne layak rakho."""

    fun ask(c: Context, text: String): JSONObject {
        val p = Prefs(c)
        require(p.key.isNotBlank()) { "Settings mein Gemini API key daalo" }
        history.add("user" to text)
        while (history.size > 20) history.removeAt(0)
        val contents = JSONArray()
        history.forEach { (r, t) ->
            contents.put(JSONObject().put("role", r).put("parts", JSONArray().put(JSONObject().put("text", t))))
        }
        val sys = "${p.persona}\nUser ka naam: ${p.name}. Use ${p.name} ya 'jaan' bulao.\n$RULES"
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val con = URL("https://generativelanguage.googleapis.com/v1beta/models/${p.model}:generateContent?key=${p.key}")
            .openConnection() as HttpURLConnection
        con.requestMethod = "POST"; con.doOutput = true; con.connectTimeout = 20000; con.readTimeout = 40000
        con.setRequestProperty("Content-Type", "application/json")
        con.outputStream.use { it.write(body.toString().toByteArray()) }
        val stream = if (con.responseCode in 200..299) con.inputStream else con.errorStream
        val resp = stream.bufferedReader().readText()
        if (con.responseCode !in 200..299) throw Exception("Gemini error ${con.responseCode}: ${resp.take(200)}")
        val out = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        val clean = out.replace("```json", "").replace("```", "").trim()
        history.add("model" to clean)
        return try { JSONObject(clean) } catch (e: Exception) { JSONObject().put("reply", clean) }
    }
}
