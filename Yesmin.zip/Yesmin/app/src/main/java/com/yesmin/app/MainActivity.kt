package com.yesmin.app
import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import org.json.JSONObject
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {
    lateinit var voice: Voice
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS), 1)
        voice = Voice(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFFF4F9A))) { Surface(Modifier.fillMaxSize()) { App(this) } } }
    }
}

@Composable
fun App(a: MainActivity) {
    var settings by remember { mutableStateOf(false) }
    val msgs = remember { mutableStateListOf<Pair<Boolean, String>>() }
    var status by remember { mutableStateOf("Mic dabao aur bolo") }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    fun send(t: String) {
        if (t.isBlank() || busy) return
        msgs.add(true to t); busy = true; status = "Soch rahi hoon..."
        thread {
            val r = try { Brain.ask(a, t) } catch (e: Exception) { JSONObject().put("reply", "Oops: ${e.message}") }
            a.runOnUiThread {
                val reply = r.optString("reply"); msgs.add(false to reply)
                r.optJSONObject("action")?.let { act -> Actions.run(a, act)?.let { msgs.add(false to it) } }
                busy = false; status = "Mic dabao aur bolo"
                if (Prefs(a).voice) { status = "Bol rahi hoon..."; a.voice.speak(reply) { a.runOnUiThread { status = "Mic dabao aur bolo" } } }
            }
        }
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Yesmin 💗", style = MaterialTheme.typography.headlineSmall)
            TextButton(onClick = { settings = !settings }) { Text(if (settings) "Chat" else "Settings") }
        }
        if (settings) SettingsScreen(a) else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), reverseLayout = false) {
                items(msgs) { (me, t) ->
                    Box(Modifier.fillMaxWidth().padding(4.dp), contentAlignment = if (me) Alignment.CenterEnd else Alignment.CenterStart) {
                        Text(t, Modifier.background(if (me) Color(0xFF3A2A4A) else Color(0xFF5A1F44), RoundedCornerShape(14.dp)).padding(10.dp))
                    }
                }
            }
            Text(status, Modifier.align(Alignment.CenterHorizontally).padding(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Type karo...") })
                TextButton(onClick = { send(input); input = "" }) { Text("Send") }
            }
            Box(Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) {
                Button(onClick = {
                    a.voice.stopSpeak(); status = "Sun rahi hoon..."
                    a.voice.listen({ t -> a.runOnUiThread { send(t) } }, { e -> a.runOnUiThread { status = e } })
                }, Modifier.size(80.dp), shape = CircleShape) { Text("🎤") }
            }
        }
    }
}

@Composable
fun SettingsScreen(a: MainActivity) {
    val p = remember { Prefs(a) }
    var key by remember { mutableStateOf(p.key) }; var model by remember { mutableStateOf(p.model) }
    var name by remember { mutableStateOf(p.name) }; var persona by remember { mutableStateOf(p.persona) }
    var voice by remember { mutableStateOf(p.voice) }
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(key, { key = it; p.key = it }, Modifier.fillMaxWidth(), label = { Text("Gemini API Key (brain)") }, singleLine = true)
        OutlinedTextField(model, { model = it; p.model = it }, Modifier.fillMaxWidth(), label = { Text("Gemini Model") }, singleLine = true)
        OutlinedTextField(name, { name = it; p.name = it }, Modifier.fillMaxWidth(), label = { Text("Tumhara naam") }, singleLine = true)
        OutlinedTextField(persona, { persona = it; p.persona = it }, Modifier.fillMaxWidth(), label = { Text("Personality prompt") }, minLines = 4)
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Voice reply", Modifier.weight(1f)); Switch(voice, { voice = it; p.voice = it }) }
        Button({ a.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, Modifier.fillMaxWidth()) { Text("Accessibility ON karo (touch control)") }
        OutlinedButton({ p.persona = Prefs.DEFAULT; persona = Prefs.DEFAULT }, Modifier.fillMaxWidth()) { Text("Personality reset") }
    }
}
