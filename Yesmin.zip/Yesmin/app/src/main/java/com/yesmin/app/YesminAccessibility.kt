package com.yesmin.app
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class YesminAccessibility : AccessibilityService() {
    companion object { var inst: YesminAccessibility? = null }
    override fun onServiceConnected() { inst = this }
    override fun onDestroy() { inst = null; super.onDestroy() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun tap(x: Float, y: Float) = gesture(x, y, x, y, 60)
    fun swipe(dir: String) {
        val w = resources.displayMetrics.widthPixels.toFloat(); val h = resources.displayMetrics.heightPixels.toFloat()
        when (dir) {
            "up" -> gesture(w / 2, h * 0.75f, w / 2, h * 0.25f, 300)
            "down" -> gesture(w / 2, h * 0.25f, w / 2, h * 0.75f, 300)
            "left" -> gesture(w * 0.8f, h / 2, w * 0.2f, h / 2, 300)
            "right" -> gesture(w * 0.2f, h / 2, w * 0.8f, h / 2, 300)
        }
    }
    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, d: Long) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, d)).build(), null, null)
    }
    fun tapText(t: String): Boolean {
        val nodes = rootInActiveWindow?.findAccessibilityNodeInfosByText(t) ?: return false
        for (n in nodes) {
            var cur: AccessibilityNodeInfo? = n
            while (cur != null) { if (cur.isClickable) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK); cur = cur.parent }
        }
        return false
    }
    fun typeText(t: String): Boolean {
        val n = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }
    fun readScreen(): String {
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || sb.length > 1500) return
            n.text?.let { sb.append(it).append(". ") }
            n.contentDescription?.let { sb.append(it).append(". ") }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rootInActiveWindow)
        return sb.toString()
    }
    fun scroll(dir: String): Boolean {
        val a = if (dir == "up") AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        fun find(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (n == null) return null
            if (n.isScrollable) return n
            for (i in 0 until n.childCount) find(n.getChild(i))?.let { return it }
            return null
        }
        return find(rootInActiveWindow)?.performAction(a) ?: false
    }
}
