package com.yesmin.app
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class Voice(private val c: Context) {
    private var tts: TextToSpeech? = null
    private var sr: SpeechRecognizer? = null
    init {
        tts = TextToSpeech(c) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val t = tts!!
                if (t.setLanguage(Locale("hi", "IN")) < 0) t.setLanguage(Locale("en", "IN"))
                t.voices?.firstOrNull { it.name.contains("female", true) && it.locale.language == "hi" }?.let { t.voice = it }
                t.setPitch(1.15f)
            }
        }
    }
    fun speak(text: String, onDone: () -> Unit = {}) {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { onDone() }
            @Deprecated("x") override fun onError(id: String?) { onDone() }
        })
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "y")
    }
    fun stopSpeak() { tts?.stop() }
    fun listen(onResult: (String) -> Unit, onFail: (String) -> Unit) {
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(c)
        sr?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle?) {
                val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) onFail("Kuch sunai nahi diya") else onResult(t)
            }
            override fun onError(e: Int) { onFail("Mic error $e") }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        sr?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
        })
    }
}
