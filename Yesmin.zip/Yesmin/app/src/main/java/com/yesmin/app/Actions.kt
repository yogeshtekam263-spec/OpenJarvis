package com.yesmin.app
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import android.accessibilityservice.AccessibilityService as AS
import org.json.JSONObject

object Actions {
    /** Naya action add karna ho to neeche `when` mein ek line jodo, aur Brain.RULES mein naam likho. */
    fun run(c: Context, a: JSONObject): String? {
        val p = a.optJSONObject("params") ?: JSONObject()
        val acc = YesminAccessibility.inst
        fun go(i: Intent) = c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        fun need(): String? = if (acc == null) "Accessibility service ON karo (Settings > Accessibility > Yesmin)" else null
        return try {
            when (a.optString("type")) {
                "open_app" -> openApp(c, p.optString("name")).also { if (!it) return "App nahi mili: ${p.optString("name")}" }.let { null }
                "youtube" -> {
                    val i = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra(SearchManager.QUERY, p.optString("query"))
                    try { go(i) } catch (e: Exception) { go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(p.optString("query"))))) }; null
                }
                "search_web" -> { go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(p.optString("query"))))); null }
                "call" -> { go(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + p.optString("number")))); null }
                "sms" -> { go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + p.optString("number"))).putExtra("sms_body", p.optString("text"))); null }
                "whatsapp" -> { go(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${p.optString("number").filter { it.isDigit() }}?text=" + Uri.encode(p.optString("text"))))); null }
                "alarm" -> { go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, p.optInt("hour")).putExtra(AlarmClock.EXTRA_MINUTES, p.optInt("minute")).putExtra(AlarmClock.EXTRA_SKIP_UI, true)); null }
                "timer" -> { go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, p.optInt("seconds")).putExtra(AlarmClock.EXTRA_SKIP_UI, true)); null }
                "maps" -> { go(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(p.optString("query"))))); null }
                "flashlight" -> { val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager; cm.setTorchMode(cm.cameraIdList[0], p.optBoolean("on", true)); null }
                "settings" -> { go(Intent(when (p.optString("page")) { "wifi" -> Settings.ACTION_WIFI_SETTINGS; "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS; else -> Settings.ACTION_SETTINGS })); null }
                "back" -> need() ?: acc!!.performGlobalAction(AS.GLOBAL_ACTION_BACK).let { null }
                "home" -> need() ?: acc!!.performGlobalAction(AS.GLOBAL_ACTION_HOME).let { null }
                "recents" -> need() ?: acc!!.performGlobalAction(AS.GLOBAL_ACTION_RECENTS).let { null }
                "tap" -> need() ?: acc!!.tap(p.optDouble("x").toFloat(), p.optDouble("y").toFloat()).let { null }
                "swipe" -> need() ?: acc!!.swipe(p.optString("direction")).let { null }
                "scroll" -> need() ?: acc!!.scroll(p.optString("direction")).let { null }
                "tap_text" -> need() ?: if (acc!!.tapText(p.optString("text"))) null else "Screen par '${p.optString("text")}' nahi mila"
                "type" -> need() ?: if (acc!!.typeText(p.optString("text"))) null else "Koi text box focus mein nahi hai"
                "read_screen" -> need() ?: "Screen: " + acc!!.readScreen()
                else -> null
            }
        } catch (e: Exception) { "Action fail: ${e.message}" }
    }

    private fun openApp(c: Context, name: String): Boolean {
        val pm = c.packageManager
        val l = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val m = l.firstOrNull { it.loadLabel(pm).toString().equals(name, true) }
            ?: l.firstOrNull { it.loadLabel(pm).toString().contains(name, true) } ?: return false
        c.startActivity(pm.getLaunchIntentForPackage(m.activityInfo.packageName)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }
}
