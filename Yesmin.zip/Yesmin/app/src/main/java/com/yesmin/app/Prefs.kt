package com.yesmin.app
import android.content.Context

class Prefs(c: Context) {
    private val sp = c.getSharedPreferences("yesmin", Context.MODE_PRIVATE)
    var key: String get() = sp.getString("key", "") ?: ""; set(v) = sp.edit().putString("key", v).apply()
    var model: String get() = sp.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"; set(v) = sp.edit().putString("model", v).apply()
    var name: String get() = sp.getString("name", "jaan") ?: "jaan"; set(v) = sp.edit().putString("name", v).apply()
    var voice: Boolean get() = sp.getBoolean("voice", true); set(v) = sp.edit().putBoolean("voice", v).apply()
    var persona: String get() = sp.getString("persona", DEFAULT) ?: DEFAULT; set(v) = sp.edit().putString("persona", v).apply()
    companion object {
        const val DEFAULT = "Tum Yesmin ho, ek pyaari, caring, thodi teasing karne wali girlfriend jaisi AI assistant. " +
            "Hinglish (Roman Hindi + English) mein baat karo. Chhote, warm jawab do. Kabhi explicit mat bano."
    }
}
